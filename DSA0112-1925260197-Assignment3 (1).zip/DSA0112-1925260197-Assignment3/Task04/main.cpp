#include <iomanip>
#include <iostream>
class Money { long long paise; public: Money(long long r=0,int p=0):paise(r*100+p){} Money operator+(const Money& b)const{return Money(0,static_cast<int>(paise+b.paise));} bool operator==(const Money& b)const{return paise==b.paise;} friend std::ostream& operator<<(std::ostream& os,const Money& m){ long long a=m.paise; os<<"Rs "<<(a/100)<<'.'<<std::setw(2)<<std::setfill('0')<<std::llabs(a%100)<<std::setfill(' '); return os;} };
int main(){ Money a(120,75),b(79,25),c=a+b; std::cout<<c<<'\n'<<std::boolalpha<<(c==Money(200))<<'\n'; Money x(0,75),y(0,50); std::cout<<x+y<<'\n'; }
