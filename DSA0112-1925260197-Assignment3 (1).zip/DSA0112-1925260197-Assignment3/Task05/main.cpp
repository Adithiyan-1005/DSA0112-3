#include <iostream>
#include <stdexcept>
#include <string>
struct Counter{int v; Counter& operator++(){++v;return *this;} Counter operator++(int){Counter old=*this;++v;return old;}};
class Time{int sec; public: explicit Time(int s=0):sec(s){} Time& operator++(){++sec;return *this;} Time operator++(int){Time old=*this;++sec;return old;} bool operator==(const Time& t)const{return sec==t.sec;} bool operator<(const Time& t)const{return sec<t.sec;} int value()const{return sec;}};
class Playlist{std::string tracks[2]{"Intro","Finale"}; public: const std::string& operator[](int i)const{if(i<0||i>=2)throw std::out_of_range("playlist index");return tracks[i];} std::string& operator[](int i){if(i<0||i>=2)throw std::out_of_range("playlist index");return tracks[i];}};
int main(){ Counter c{5}; Counter a=c++; Counter b=++c; std::cout<<a.v<<' '<<b.v<<' '<<c.v<<'\n'; Time t(3599); Time old=t++; Time now=++t; std::cout<<old.value()<<' '<<now.value()<<'\n'; Playlist p; std::cout<<p[0]<<' '<<p[1]<<'\n'; try{std::cout<<p[-1];}catch(const std::exception&e){std::cout<<"Checked: "<<e.what()<<'\n';} }
