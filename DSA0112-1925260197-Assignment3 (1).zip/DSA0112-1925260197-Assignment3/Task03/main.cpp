#include <iostream>
#include <memory>
class Event {
    int rows,seats; char** map;
public:
    Event(int r,int s):rows(r>0?r:0),seats(s>0?s:0),map(rows?new char*[rows]:nullptr){ for(int i=0;i<rows;++i){ map[i]=new char[seats]; for(int j=0;j<seats;++j) map[i][j]='O'; } std::cout<<"Open "<<rows<<'x'<<seats<<'\n'; }
    ~Event(){ for(int i=0;i<rows;++i) delete[] map[i]; delete[] map; std::cout<<"Close "<<rows<<'x'<<seats<<'\n'; }
    bool book(int r,int s){ if(r<0||r>=rows||s<0||s>=seats||map[r][s]=='X') return false; map[r][s]='X'; return true; }
    bool cancel(int r,int s){ if(r<0||r>=rows||s<0||s>=seats||map[r][s]=='O') return false; map[r][s]='O'; return true; }
};
int main(){ Event stack(2,3); stack.book(0,1); { Event block(1,2); block.book(0,0); } Event* heap=new Event(1,1); heap->book(0,0); delete heap; Event zero(0,4); }
