from docx import Document
from docx.shared import Inches, Pt
from PIL import Image, ImageDraw, ImageFont
from pathlib import Path
root=Path('.')
# Output capture images
fontpath='/usr/share/fonts/truetype/dejavu/DejaVuSansMono.ttf'
font=ImageFont.truetype(fontpath,18)
for d in sorted(root.glob('Task[0-9][0-9]')):
    out=d/'output.txt'
    if not out.exists(): continue
    lines=(out.read_text(errors='replace').splitlines() or ['(no output)'])
    width=max(780,max(font.getlength(line) for line in lines)+70)
    height=90+len(lines)*32
    im=Image.new('RGB',(int(width),height),(25,27,32)); dr=ImageDraw.Draw(im)
    dr.text((24,20),'$ ./program',font=font,fill=(140,220,140))
    for i,line in enumerate(lines): dr.text((24,60+i*32),line,font=font,fill=(230,230,230))
    im.save(d/'output.png')

report=Document()
report.add_heading('Assignment 3 – CO3',0)
report.add_paragraph('Constructors, Destructors and Operator Overloading')
report.add_paragraph('Student: [Enter your name]')
report.add_paragraph('Register number: 1925260197')
report.add_paragraph('Repository: DSA0112-1925260197-Assignment3')
report.add_paragraph('GitHub URL: [Add after publishing repository]')
report.add_page_break()
report.add_heading('Compiler and execution',1)
report.add_paragraph('GNU g++ (Debian 14.2.0-19), C++17. Compile each folder with: g++ -std=c++17 -Wall -Wextra -pedantic main.cpp -o program. Run with ./program. The output.txt files and output.png captures record the local executions. AddressSanitizer builds are included for Tasks 02, 03 and 06.')
sections=[
('Q1 – Constructors and constructor overloading','Book provides a default constructor, title-only donated-book constructor, and full parameterized constructor. Delegation routes all construction through one validating constructor. Member initializer lists initialize members directly; initialization order follows declaration order, not initializer-list order. A user-declared non-default constructor prevents the compiler from implicitly supplying a default constructor. Initializer lists avoid default-construct-then-assign and are required for const/reference members. Negative copies throw invalid_argument. A constructor should be explicit when it must not act as an implicit conversion; for example explicit Book(std::string) rejects Book b = "title". Object construction is O(1) time and O(1) object space, excluding string storage. A single constructor with default arguments reduces overload count but centralizes parameter handling; validation should remain in one place.'),
('Q2 – Shallow and deep copies','The completed Prescription uses a newly allocated array in its copy constructor and copy assignment, guards self-assignment, then releases the old storage. Destructor uses delete[]. Expected output: Ibuprofen ORS | Paracetamol Cetirizine | Paracetamol ORS. A shallow copy duplicates only the pointer: both objects point to the same array, causing shared changes and double deletion. Deep-copy diagram: p -> [Paracetamol, ORS]; q -> [Paracetamol, Cetirizine]; r -> [Paracetamol, ORS]. Rule of Three: if a class needs destructor, copy constructor, or copy assignment, it usually needs all three. Copy constructor occurs in direct copy initialization, passing by value, and returning by value (subject to elision). Compiler-generated copying is suitable for value members such as std::string/vector; raw owning pointers require custom management. Copying n medicines takes O(n) time and O(n) extra space; shallow pointer copy is O(1) but incorrect for ownership. Vector enables Rule of Zero.'),
('Q3 – Dynamic constructors and destructors','Event allocates an array of row pointers and one char array per row; destructor deletes every row then the pointer array. Local objects destruct in reverse construction order; block objects destruct at block exit; heap objects survive until delete. Missing delete leaks; delete instead of delete[] is undefined behavior for arrays. A destructor has no parameters and cannot be overloaded because destruction has one fixed operation per object. Seat map layout: Event -> map[0..rows-1] -> each row[0..seats-1]. Logger prediction: +A +B -B copyAc use -Ac +P -P end -A . The B object ends at block exit, parameter copy Ac is made for pass-by-value and destroyed after use, heap P is deleted explicitly, and A ends at main exit. RAII ties release to lifetime. One contiguous allocation uses one allocation and indexing r*seats+s; row-pointer layout uses rows+1 allocations and row pointers. Access is O(1); allocation/storage O(rows*seats), plus O(rows) pointers.'),
('Q4 – Arithmetic and stream operators','Money stores integer paise to avoid floating-point representation error. + returns a new value; += conventionally modifies and returns Money& to allow chaining and avoid a copy. << is a non-member because the left operand is ostream. In a+b, the member form translates to a.operator+(b); a friend/non-member form translates to operator+(a,b). + and == are members in the implementation; << is a friend non-member. Results: Rs 200.00, true, and Rs 1.25 for the carry test. Negative amounts are representable; applications may reject them at validation boundaries. Multiplication of Money by Money has no natural currency meaning; scalar multiplication is more appropriate. All arithmetic/comparison operations are O(1) time and O(1) space.'),
('Q5 – Increment, comparison and subscript','Prefix ++ returns the updated object by reference; postfix is distinguished by a dummy int and returns the old value by copy. Prediction for Counter: 5 7 7. After c++ a receives 5 and c becomes 6; ++c increments to 7 and b refers to updated value 7. Postfix creates a copy; prefix does not. Playlist has const and mutable [] overloads so const objects can be read and mutable objects can be changed. Out-of-range indices throw std::out_of_range rather than accessing invalid memory. Time and array access are O(1); a range check adds one comparison. ++i is generally preferred for class types to avoid the old-value copy. Benchmark timings should be recorded on the student’s machine at -O0/-O2 because they depend on compiler, CPU and optimization.'),
('Q6 – Operator overloading rules','Text owns a character array and implements constructor, deep-copy constructor, copy assignment with self-assignment guard, destructor, concatenation, equality/inequality and stream output. The non-overloadable operators are ::, ., .*, ?: and sizeof. Precedence and operand count cannot change; at least one operand must be a user-defined type. operator= must be a member. A friend is useful when a non-member needs private access or when the left operand is a stream. For a+b+c, intermediate concatenation copies characters into a temporary; work is proportional to the lengths involved, O(n1+n2+n3) for the two concatenations under the usual string-copy model, with temporary storage. std::string is safer and usually preferred; a custom class is educational or justified by specialized storage/ABI requirements. AddressSanitizer run is included.'),
('Q7 – Complex number design','Complex stores real and imaginary doubles. Constructors cover zero, real-only, and real+imaginary values. Addition: (a+c)+(b+d)j; subtraction: (a-c)+(b-d)j; multiplication: (ac-bd)+(ad+bc)j; division uses denominator c²+d² and throws on zero. Equality compares both components. Series example R=10, L=5j, C=-2j gives 10+3j and magnitude sqrt(109)=10.4403. Parallel R and L gives (10*5j)/(10+5j)=2+4j, magnitude sqrt(20)=4.47214. std::complex<double> offers tested standard operations and less implementation work; custom class makes policy and division-by-zero behavior explicit. Limitation: exact floating-point equality is fragile; tolerance-based comparison is needed for computed values. Each operation is O(1) time and O(1) space (two doubles).')]
for title,body in sections:
    report.add_heading(title,1); report.add_paragraph(body)
    task=title.split(' ')[0].replace('Q','Task')
    folder={'Task01':'Task01','Task02':'Task02','Task03':'Task03','Task04':'Task04','Task05':'Task05','Task06':'Task06','Task07':'Task07'}.get(task)
    if folder and (root/folder/'output.png').exists(): report.add_picture(str(root/folder/'output.png'),width=Inches(5.8))
report.add_heading('Testing and evidence checklist',1)
for item in ['All seven main.cpp programs compiled with g++ C++17 and -Wall -Wextra -pedantic.','Main output captured in output.txt and output.png per task.','ASan build/output/report files included for Tasks 02, 03 and 06.','Before submission, add required additional experimental timings, exact negative compile diagnostics and any requested memory diagrams as screenshots.','Fill in student name and actual GitHub URL; publish and share repository; submit report through Google Classroom.']:
    report.add_paragraph(item,style='List Bullet')
report.save('Assignment3_Report.docx')
