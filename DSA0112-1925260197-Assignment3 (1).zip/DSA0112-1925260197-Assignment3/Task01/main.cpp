#include <iostream>
#include <string>
#include <stdexcept>
class Book {
    std::string title, author; int copies;
    static int checked(int n) { if(n<0) throw std::invalid_argument("copies cannot be negative"); return n; }
public:
    Book() : Book("", "", 0) {}
    explicit Book(std::string t) : Book(std::move(t), "Unknown", 1) {}
    Book(std::string t, std::string a, int c) : title(std::move(t)), author(std::move(a)), copies(checked(c)) {}
    void print() const { std::cout << '[' << title << ", " << author << ", copies=" << copies << "]\n"; }
};
int main(){ Book empty; Book donated("Donated title"); Book full("C++ Primer","Lippman",4); empty.print(); donated.print(); full.print(); try { Book invalid("Bad","Author",-2); invalid.print(); } catch(const std::exception& e){ std::cout << "Rejected: " << e.what() << '\n'; } }
